import SwiftUI

@main
struct RaidIQApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
